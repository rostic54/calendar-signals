# Calendar

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 17.3.0.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

In the calendar app you can create appointments for specific dates and time.    
There are several events allowed to do with the appointment:

- Drag & Drop them within the month view, includes days from previous and next month
- Creat appointments in the day details. Create for specific hour before selected one.
- Edit appointments by click it on the /general screen 


export interface Information {
  info: string;
}

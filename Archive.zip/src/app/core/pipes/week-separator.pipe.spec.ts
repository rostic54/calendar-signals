import { WeekSeparatorPipe } from './week-separator.pipe';

describe('WeekSeparatorPipe', () => {
  it('create an instance', () => {
    const pipe = new WeekSeparatorPipe();
    expect(pipe).toBeTruthy();
  });
});

export class ScheduledEvent {
  id: number;
  currentDate: Date;
  content: string;
  editable: boolean;

  constructor(date: Date, content: string, editable = false, id?: number) {
    this.id = id || date.getTime();
    this.currentDate = date;
    this.content = content;
    this.editable = editable;
  }

  get year(): number {
    return this.currentDate.getFullYear();
  }

  get month(): number {
    return this.currentDate.getMonth();
  }

  get dateHour(): number {
    return this.currentDate.getHours();
  }

  get dateMinutes(): number {
    return this.currentDate.getMinutes();
  }

  get preciseTime(): string {
    const hours = String(this.dateHour).padStart(2, '0');
    const minutes = String(this.dateMinutes).padStart(2, '0');
    return `${hours}:${minutes}`
  }

}
